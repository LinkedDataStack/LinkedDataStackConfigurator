edcat-core
==========

Core EDCAT implementation.

### License
See [edcat license] (https://github.com/tenforce/edcat/blob/master/license.md)
