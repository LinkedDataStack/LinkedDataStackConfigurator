package eu.lod2.hooks.contexts.distribution;

/**
 * Parent Context for Distribution-related hooks.
 */
public abstract class Context extends eu.lod2.hooks.contexts.Context {
}
