package eu.lod2.hooks.contexts.catalog;

/**
 * Parent Context for Catalog-related hooks.
 */
public abstract class Context extends eu.lod2.hooks.contexts.Context {
}
