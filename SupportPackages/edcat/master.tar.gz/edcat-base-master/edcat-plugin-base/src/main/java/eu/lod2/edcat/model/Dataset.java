package eu.lod2.edcat.model;

/**
 * Represents a Dataset and all operations which may occur on it.
 */
public class Dataset {



}
