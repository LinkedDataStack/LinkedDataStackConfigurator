package eu.lod2.hooks.contexts.dataset;

/**
 * Parent Context for Dataset-related hooks.
 */
@SuppressWarnings( "UnusedDeclaration" )
public class Context extends eu.lod2.hooks.contexts.Context {
}
