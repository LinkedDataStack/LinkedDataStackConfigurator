package eu.lod2.edcat.utils;

public enum StoreType {
  memory,virtuoso,sesame_remote
}
