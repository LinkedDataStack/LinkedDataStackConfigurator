package eu.lod2.edcat.utils;

import java.util.Map;
import java.util.Vector;

public class QueryResult extends Vector<Map<String, String>> {
}
